const socket = io();
let txtCifrado = document.getElementById('msg1');
let username = document.getElementById('username');
let btn = document.getElementById('send');
let output = document.getElementById('output');
let actions = document.getElementById('actions');

btn.addEventListener('click', function () {
    const file = txtCifrado.files[0];
    if (file) {
        const reader = new FileReader();

        reader.onload = function (event) {
            const cifrado = event.target.result;
            const fileMessage = {
                username: username.value,
                fileName: file.name,
                cifrado: cifrado,
            };

            socket.emit('chat:message', fileMessage); // Envia el archivo como mensaje
        };

        reader.readAsDataURL(file);
    }
});

message.addEventListener('keypress', function () {
    console.log(username.value);
    socket.emit('chat:typing', username.value);
});

socket.on('chat:message', function (data) {
    if (data.fileName && data.cifrado) {
        // Si recibes un mensaje con un archivo, muestra un enlace de descarga
        actions.innerHTML = `
            <p>
                <strong>${data.username}</strong> ha compartido un archivo cifrado:
                <a href="${data.cifrado}" download="${data.fileName}">Descargar Archivo Cifrado</a>
            </p>
        `;
    } else {
        // Si no es un archivo, muestra el mensaje de texto
        actions.innerHTML = '';
        output.innerHTML += `<p><strong>${data.username}</strong>: ${data.message}</p>`;
    }
});

socket.on('chat:typing', function (data) {
    actions.innerHTML = `<p><em>${data} está escribiendo</em></p>`;
})